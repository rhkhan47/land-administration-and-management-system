<?php
require_once "config.php";

if (!isLoggedIn() || !isAdmin()) {
    header("location: login.php");
    exit;
}

// Get pending users
$pending_users = [];
$sql = "SELECT id, name, national_id, email, dob, permanent_address, created_at FROM users WHERE status = 'Pending'";
if ($result = mysqli_query($link, $sql)) {
    while ($row = mysqli_fetch_assoc($result)) {
        $pending_users[] = $row;
    }
    mysqli_free_result($result);
}

// Get all land assets
$land_assets = [];
$sql = "SELECT la.*, u.name as owner_name FROM land_assets la JOIN users u ON la.owner_id = u.id";
if ($result = mysqli_query($link, $sql)) {
    while ($row = mysqli_fetch_assoc($result)) {
        $land_assets[] = $row;
    }
    mysqli_free_result($result);
}

// Get pending transactions
$pending_transactions = [];
$sql = "SELECT t.*, la.location as land_location, seller.name as seller_name, buyer.name as buyer_name 
        FROM transactions t 
        JOIN land_assets la ON t.asset_id = la.id 
        LEFT JOIN users seller ON t.seller_id = seller.id 
        LEFT JOIN users buyer ON t.buyer_id = buyer.id 
        WHERE t.status = 'Pending'";
if ($result = mysqli_query($link, $sql)) {
    while ($row = mysqli_fetch_assoc($result)) {
        $pending_transactions[] = $row;
    }
    mysqli_free_result($result);
}

// Handle user approval
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["approve_user"])) {
        $user_id = (int)$_POST["user_id"];
        // Approve in the local DB
        $sql = "UPDATE users SET status = 'Active' WHERE id = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "i", $user_id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
        // Approve on the blockchain
        try {
            $chaincodeUserId = 'user' . $user_id;
            fabric_invoke('approveUser', [$chaincodeUserId]);
        } catch (Exception $e) {
            error_log('Error approving user on blockchain: ' . $e->getMessage());
        }
        header("location: admin_dashboard.php");
    } elseif (isset($_POST["reject_user"])) {
        $user_id = (int)$_POST["user_id"];
        $sql = "UPDATE users SET status = 'Rejected' WHERE id = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "i", $user_id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
        // Note: there is no chaincode concept of rejection; we simply leave the user unapproved.
        header("location: admin_dashboard.php");
    } elseif (isset($_POST["approve_land"])) {
        $land_id = (int)$_POST["land_id"];
        // Approve in the local DB
        $sql = "UPDATE land_assets SET status = 'Owned' WHERE id = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "i", $land_id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
        // Approve on the blockchain
        try {
            $chaincodeLandId = (string)$land_id;
            fabric_invoke('approveLand', [$chaincodeLandId]);
        } catch (Exception $e) {
            error_log('Error approving land on blockchain: ' . $e->getMessage());
        }
        header("location: admin_dashboard.php");
    } elseif (isset($_POST["reject_land"])) {
        $land_id = (int)$_POST["land_id"];
        // Reject locally; there is no chaincode reject
        $sql = "UPDATE land_assets SET status = 'Rejected' WHERE id = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "i", $land_id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
        header("location: admin_dashboard.php");
    } elseif (isset($_POST["approve_transaction"])) {
        $transaction_id = (int)$_POST["transaction_id"];
        // Get transaction details
        $sql = "SELECT * FROM transactions WHERE id = ?";
        $transaction = null;
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "i", $transaction_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $transaction = mysqli_fetch_assoc($result);
            mysqli_stmt_close($stmt);
        }
        if ($transaction) {
            $assetId           = (int)$transaction['asset_id'];
            $buyerId           = (int)$transaction['buyer_id'];
            $sellerId          = (int)$transaction['seller_id'];
            $durationMonths    = isset($transaction['duration_months']) ? (int)$transaction['duration_months'] : 0;
            $amount            = isset($transaction['amount']) ? (float)$transaction['amount'] : 0;
            $assetChaincodeId  = (string)$assetId;
            $buyerChaincodeId  = 'user' . $buyerId;
            // Determine the type and act accordingly
            if ($transaction['type'] == 'Buy') {
                // Confirm sale on blockchain
                try {
                    fabric_invoke('confirmSale', [$assetChaincodeId]);
                } catch (Exception $e) {
                    error_log('Error confirming sale on blockchain: ' . $e->getMessage());
                }
                // Update land ownership locally
                $sql = "UPDATE land_assets SET owner_id = ?, status = 'Owned', price = NULL WHERE id = ?";
                if ($stmt = mysqli_prepare($link, $sql)) {
                    mysqli_stmt_bind_param($stmt, "ii", $buyerId, $assetId);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }
                // Mark transaction complete
                $sql = "UPDATE transactions SET status = 'Completed' WHERE id = ?";
                if ($stmt = mysqli_prepare($link, $sql)) {
                    mysqli_stmt_bind_param($stmt, "i", $transaction_id);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }
            } elseif ($transaction['type'] == 'Mortgage') {
                // Accept mortgage on blockchain
                try {
                    fabric_invoke('acceptMortgage', [$assetChaincodeId, $buyerChaincodeId]);
                } catch (Exception $e) {
                    error_log('Error accepting mortgage on blockchain: ' . $e->getMessage());
                }
                // Locally mark land as mortgaged and set temporary owner
                $sql = "UPDATE land_assets SET owner_id = ?, status = 'Mortgaged' WHERE id = ?";
                if ($stmt = mysqli_prepare($link, $sql)) {
                    mysqli_stmt_bind_param($stmt, "ii", $buyerId, $assetId);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }
                // Set start and end dates
                $end_date = date('Y-m-d', strtotime('+' . $durationMonths . ' months'));
                $sql = "UPDATE transactions SET status = 'Completed', start_date = CURDATE(), end_date = ? WHERE id = ?";
                if ($stmt = mysqli_prepare($link, $sql)) {
                    mysqli_stmt_bind_param($stmt, "si", $end_date, $transaction_id);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }
            } elseif ($transaction['type'] == 'Lease') {
                // Accept lease on blockchain
                try {
                    fabric_invoke('acceptLease', [$assetChaincodeId, $buyerChaincodeId]);
                } catch (Exception $e) {
                    error_log('Error accepting lease on blockchain: ' . $e->getMessage());
                }
                // Locally mark land as leased and change owner temporarily
                $sql = "UPDATE land_assets SET owner_id = ?, status = 'Leased' WHERE id = ?";
                if ($stmt = mysqli_prepare($link, $sql)) {
                    mysqli_stmt_bind_param($stmt, "ii", $buyerId, $assetId);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }
                // Set start and end dates
                $end_date = date('Y-m-d', strtotime('+' . $durationMonths . ' months'));
                $sql = "UPDATE transactions SET status = 'Completed', start_date = CURDATE(), end_date = ? WHERE id = ?";
                if ($stmt = mysqli_prepare($link, $sql)) {
                    mysqli_stmt_bind_param($stmt, "si", $end_date, $transaction_id);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }
            }
            header("location: admin_dashboard.php");
        }
    } elseif (isset($_POST["reject_transaction"])) {
        $transaction_id = (int)$_POST["transaction_id"];
        // Mark transaction as rejected locally
        $sql = "UPDATE transactions SET status = 'Rejected' WHERE id = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "i", $transaction_id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
        // Fetch transaction to revert land status
        $sql = "SELECT * FROM transactions WHERE id = ?";
        $transaction = null;
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "i", $transaction_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $transaction = mysqli_fetch_assoc($result);
            mysqli_stmt_close($stmt);
        }
        if ($transaction) {
            $assetId = (int)$transaction['asset_id'];
            // Update land status based on type
            if ($transaction['type'] == 'Buy') {
                $newStatus = 'ForSale';
            } elseif ($transaction['type'] == 'Mortgage') {
                $newStatus = 'ForMortgage';
            } elseif ($transaction['type'] == 'Lease') {
                $newStatus = 'ForLease';
            } else {
                $newStatus = null;
            }
            if ($newStatus) {
                $sql = "UPDATE land_assets SET status = ? WHERE id = ?";
                if ($stmt = mysqli_prepare($link, $sql)) {
                    mysqli_stmt_bind_param($stmt, "si", $newStatus, $assetId);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }
            }
        }
        header("location: admin_dashboard.php");
    }
}

mysqli_close($link);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Land Administration System</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1><i class="fas fa-cogs"></i> Land Inspector Dashboard</h1>
                <div class="user-info">
                    <div class="user-welcome">
                        <i class="fas fa-user-circle"></i>
                        <span>Welcome, <?php echo $_SESSION["name"]; ?></span>
                    </div>
                    <div class="user-actions">
                        <a href="logout.php" class="btn btn-outline"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>
        </header>
        
        <div class="dashboard-tabs">
            <button class="tab-btn active" onclick="openTab('pending-users')"><i class="fas fa-users"></i> Pending Users</button>
            <button class="tab-btn" onclick="openTab('land-assets')"><i class="fas fa-landmark"></i> Land Assets</button>
            <button class="tab-btn" onclick="openTab('pending-transactions')"><i class="fas fa-exchange-alt"></i> Pending Transactions</button>
        </div>
        
        <div class="dashboard-content">
            <div id="pending-users" class="tab-content active">
                <h2><i class="fas fa-users"></i> Pending User Approvals</h2>
                <?php if (count($pending_users) > 0): ?>
                    <div class="card-container">
                        <?php foreach ($pending_users as $user): ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3><?php echo $user['name']; ?></h3>
                                    <span class="status-badge status-pending">Pending</span>
                                </div>
                                <div class="card-body">
                                    <p><strong>National ID:</strong> <?php echo $user['national_id']; ?></p>
                                    <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
                                    <p><strong>Date of Birth:</strong> <?php echo $user['dob']; ?></p>
                                    <p><strong>Permanent Address:</strong> <?php echo $user['permanent_address']; ?></p>
                                    <p><strong>Registration Date:</strong> <?php echo $user['created_at']; ?></p>
                                </div>
                                <div class="card-actions">
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" name="approve_user" class="btn btn-success"><i class="fas fa-check"></i> Approve</button>
                                    </form>
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                        <button type="submit" name="reject_user" class="btn btn-danger"><i class="fas fa-times"></i> Reject</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-users"></i>
                        <h3>No Pending Users</h3>
                        <p>No pending user approvals at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div id="land-assets" class="tab-content">
                <h2><i class="fas fa-landmark"></i> All Land Assets</h2>
                <?php if (count($land_assets) > 0): ?>
                    <div class="card-container">
                        <?php foreach ($land_assets as $land): ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3><?php echo $land['location']; ?></h3>
                                    <span class="status-badge status-<?php echo strtolower($land['status']); ?>"><?php echo $land['status']; ?></span>
                                </div>
                                <div class="card-body">
                                    <p><strong>Area:</strong> <?php echo $land['area']; ?> sq ft</p>
                                    <p><strong>Owner:</strong> <?php echo $land['owner_name']; ?></p>
                                    <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo $land['ipfs_cid']; ?></span></p>
                                    <p><strong>Deed Hash:</strong> <span class="monospace"><?php echo $land['deed_hash']; ?></span></p>
                                    <?php if ($land['price']): ?>
                                        <p><strong>Price:</strong> ৳<?php echo number_format($land['price'], 2); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="card-actions">
                                    <?php if ($land['status'] == 'Pending'): ?>
                                        <form method="post" style="display: inline;">
                                            <input type="hidden" name="land_id" value="<?php echo $land['id']; ?>">
                                            <button type="submit" name="approve_land" class="btn btn-success"><i class="fas fa-check"></i> Approve</button>
                                        </form>
                                        <form method="post" style="display: inline;">
                                            <input type="hidden" name="land_id" value="<?php echo $land['id']; ?>">
                                            <button type="submit" name="reject_land" class="btn btn-danger"><i class="fas fa-times"></i> Reject</button>
                                        </form>
                                    <?php else: ?>
                                        <span class="status-approved">Processed</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-landmark"></i>
                        <h3>No Land Assets</h3>
                        <p>No land assets registered in the system.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div id="pending-transactions" class="tab-content">
                <h2><i class="fas fa-exchange-alt"></i> Pending Transactions</h2>
                <?php if (count($pending_transactions) > 0): ?>
                    <div class="card-container">
                        <?php foreach ($pending_transactions as $transaction): ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3>Transaction #<?php echo $transaction['id']; ?></h3>
                                    <span class="status-badge status-pending">Pending</span>
                                </div>
                                <div class="card-body">
                                    <p><strong>Type:</strong> <?php echo $transaction['type']; ?></p>
                                    <p><strong>Land:</strong> <?php echo $transaction['land_location']; ?></p>
                                    <p><strong>Seller:</strong> <?php echo $transaction['seller_name']; ?></p>
                                    <?php if ($transaction['buyer_name']): ?>
                                        <p><strong>Buyer:</strong> <?php echo $transaction['buyer_name']; ?></p>
                                    <?php endif; ?>
                                    <?php if ($transaction['amount']): ?>
                                        <p><strong>Amount:</strong> ৳<?php echo number_format($transaction['amount'], 2); ?></p>
                                    <?php endif; ?>
                                    <?php if ($transaction['duration_months']): ?>
                                        <p><strong>Duration:</strong> <?php echo $transaction['duration_months']; ?> months</p>
                                    <?php endif; ?>
                                    <p><strong>Created At:</strong> <?php echo $transaction['created_at']; ?></p>
                                </div>
                                <div class="card-actions">
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="transaction_id" value="<?php echo $transaction['id']; ?>">
                                        <button type="submit" name="approve_transaction" class="btn btn-success"><i class="fas fa-check"></i> Approve</button>
                                    </form>
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="transaction_id" value="<?php echo $transaction['id']; ?>">
                                        <button type="submit" name="reject_transaction" class="btn btn-danger"><i class="fas fa-times"></i> Reject</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-exchange-alt"></i>
                        <h3>No Pending Transactions</h3>
                        <p>No pending transactions at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function openTab(tabName) {
            // Hide all tab contents
            var tabContents = document.getElementsByClassName("tab-content");
            for (var i = 0; i < tabContents.length; i++) {
                tabContents[i].classList.remove("active");
            }
            
            // Remove active class from all buttons
            var tabButtons = document.getElementsByClassName("tab-btn");
            for (var i = 0; i < tabButtons.length; i++) {
                tabButtons[i].classList.remove("active");
            }
            
            // Show the selected tab and mark button as active
            document.getElementById(tabName).classList.add("active");
            event.currentTarget.classList.add("active");
        }
    </script>
    <script src="js/script.js"></script>
</body>
</html>