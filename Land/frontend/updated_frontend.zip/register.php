<?php
require_once "config.php";

// Redirect logged in users to their dashboard
if (isLoggedIn()) {
    header("location: " . (isAdmin() ? "admin_dashboard.php" : "user_dashboard.php"));
    exit;
}

$name = $national_id = $email = $password = $confirm_password = $dob = $permanent_address = "";
$name_err = $national_id_err = $email_err = $password_err = $confirm_password_err = $dob_err = $permanent_address_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate name
    if (empty(trim($_POST["name"]))) {
        $name_err = "Please enter your name.";
    } else {
        $name = trim($_POST["name"]);
    }
    // Validate national ID
    if (empty(trim($_POST["national_id"]))) {
        $national_id_err = "Please enter your National ID.";
    } else {
        $national_id = trim($_POST["national_id"]);
        // Check if national ID already exists
        $sql = "SELECT id FROM users WHERE national_id = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_nid);
            $param_nid = $national_id;
            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);
                if (mysqli_stmt_num_rows($stmt) > 0) {
                    $national_id_err = "This National ID is already registered.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }
    }
    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter an email.";
    } else {
        $email = trim($_POST["email"]);
        // Check if email already exists
        $sql = "SELECT id FROM users WHERE email = ?";
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_email);
            $param_email = $email;
            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);
                if (mysqli_stmt_num_rows($stmt) > 0) {
                    $email_err = "This email is already registered.";
                }
            } else {
                echo "Oops! Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }
    }
    // Validate date of birth
    if (empty(trim($_POST["dob"]))) {
        $dob_err = "Please enter your date of birth.";
    } else {
        $dob = trim($_POST["dob"]);
    }
    // Validate permanent address
    if (empty(trim($_POST["permanent_address"]))) {
        $permanent_address_err = "Please enter your permanent address.";
    } else {
        $permanent_address = trim($_POST["permanent_address"]);
    }
    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "Password must have at least 6 characters.";
    } else {
        $password = trim($_POST["password"]);
    }
    // Validate confirm password
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm password.";
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }
    // If no errors, insert into database and register on blockchain
    if (empty($name_err) && empty($national_id_err) && empty($email_err) && empty($password_err) && empty($confirm_password_err) && empty($dob_err) && empty($permanent_address_err)) {
        $sql = "INSERT INTO users (name, national_id, email, password, dob, permanent_address) VALUES (?, ?, ?, ?, ?, ?)";
        if ($stmt = mysqli_prepare($link, $sql)) {
            mysqli_stmt_bind_param($stmt, "ssssss", $param_name, $param_nid, $param_email, $param_password, $param_dob, $param_address);
            $param_name    = $name;
            $param_nid     = $national_id;
            $param_email   = $email;
            $param_password= password_hash($password, PASSWORD_DEFAULT);
            $param_dob     = $dob;
            $param_address = $permanent_address;
            if (mysqli_stmt_execute($stmt)) {
                $new_user_id = mysqli_insert_id($link);
                mysqli_stmt_close($stmt);
                // Register the user on the blockchain
                try {
                    $personalDetails = [
                        'name' => $name,
                        'email' => $email,
                        'dob' => $dob,
                        'permanent_address' => $permanent_address
                    ];
                    $chaincodeUserId = 'user' . $new_user_id;
                    fabric_invoke('registerUser', [$chaincodeUserId, $national_id, json_encode($personalDetails)]);
                } catch (Exception $e) {
                    error_log('Error registering user on blockchain: ' . $e->getMessage());
                }
                header("location: login.php?registered=1");
                exit;
            } else {
                mysqli_stmt_close($stmt);
                echo "Something went wrong. Please try again later.";
            }
        }
        mysqli_close($link);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Land Administration System</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="form-wrapper">
            <div class="form-header">
                <h2><i class="fas fa-user-plus"></i> User Registration</h2>
                <p>Please fill in your details to create an account.</p>
            </div>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group <?php echo (!empty($name_err)) ? 'has-error' : ''; ?>">
                    <label>Full Name</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-user"></i></span>
                        <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($name); ?>">
                    </div>
                    <span class="help-block"><?php echo $name_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($national_id_err)) ? 'has-error' : ''; ?>">
                    <label>National ID</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-id-card"></i></span>
                        <input type="text" name="national_id" class="form-control" value="<?php echo htmlspecialchars($national_id); ?>">
                    </div>
                    <span class="help-block"><?php echo $national_id_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
                    <label>Email</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-envelope"></i></span>
                        <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>">
                    </div>
                    <span class="help-block"><?php echo $email_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($dob_err)) ? 'has-error' : ''; ?>">
                    <label>Date of Birth</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-calendar"></i></span>
                        <input type="date" name="dob" class="form-control" value="<?php echo htmlspecialchars($dob); ?>">
                    </div>
                    <span class="help-block"><?php echo $dob_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($permanent_address_err)) ? 'has-error' : ''; ?>">
                    <label>Permanent Address</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-home"></i></span>
                        <textarea name="permanent_address" class="form-control" rows="3"><?php echo htmlspecialchars($permanent_address); ?></textarea>
                    </div>
                    <span class="help-block"><?php echo $permanent_address_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                    <label>Password</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-lock"></i></span>
                        <input type="password" name="password" class="form-control" value="<?php echo htmlspecialchars($password); ?>">
                    </div>
                    <span class="help-block"><?php echo $password_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>">
                    <label>Confirm Password</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-lock"></i></span>
                        <input type="password" name="confirm_password" class="form-control" value="<?php echo htmlspecialchars($confirm_password); ?>">
                    </div>
                    <span class="help-block"><?php echo $confirm_password_err; ?></span>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="Register">
                    <input type="reset" class="btn btn-default" value="Reset">
                </div>
                <div class="form-footer">
                    <p>Already have an account? <a href="login.php">Login here</a>.</p>
                </div>
            </form>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>