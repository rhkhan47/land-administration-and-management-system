<?php
// Modified configuration for blockchain-based backend
//
// This file replaces the original MySQL configuration and helper
// functions with equivalents that communicate with the Hyperledger
// Fabric REST API provided by server.js.  The API base URL is
// configurable via the API_BASE_URL constant below.  All helpers
// return simple PHP arrays; when an API call fails they return
// empty arrays to avoid PHP warnings in the UI.

session_start();

// Base URL for the NodeJS API that proxies Hyperledger Fabric
// operations.  Adjust this if your backend runs on a different
// host or port.  The default port of server.js is 3000.
define('API_BASE_URL', 'http://localhost:3000');

/**
 * Perform an HTTP request against the fabric-app API.
 *
 * @param string $method HTTP method ("GET" or "POST").
 * @param string $url    Full URL to request (relative to API_BASE_URL).
 * @param array|null $data Optional request payload for POST requests.
 * @return array|null Decoded JSON response or null on failure.
 */
function callAPI($method, $url, $data = null) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    // Encode and send JSON payload for POST bodies
    if (strtoupper($method) === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    }
    $response = curl_exec($ch);
    $err      = curl_error($ch);
    curl_close($ch);
    if ($err) {
        return null;
    }
    $decoded = json_decode($response, true);
    return $decoded;
}

/**
 * Determine if a user is currently logged in.  Uses PHP
 * session variables only.
 *
 * @return bool
 */
function isLoggedIn() {
    return isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true;
}

/**
 * Determine if the current user is an administrator.  Relies on
 * a session variable set at login time.
 *
 * @return bool
 */
function isAdmin() {
    return isset($_SESSION["user_type"]) && $_SESSION["user_type"] === "Admin";
}

/**
 * Fetch all lands owned by a particular user.  Uses the
 * `queryOwnedLand` chaincode function via the generic query endpoint.
 * Optionally filters by status.
 *
 * @param string $user_id  Identifier of the owner (same as their userId in chaincode)
 * @param string|null $status Optional status to filter results on
 * @return array
 */
function getUserLands($user_id, $status = null) {
    $resp = callAPI('POST', API_BASE_URL . '/api/query', [
        'fcn'  => 'queryOwnedLand',
        'args' => [$user_id],
    ]);
    if (!$resp || empty($resp['ok'])) {
        return [];
    }
    $lands = $resp['result'];
    // Filter by status if provided
    if ($status) {
        $lands = array_filter($lands, function ($l) use ($status) {
            return isset($l['status']) && $l['status'] === $status;
        });
    }
    return $lands;
}

/**
 * Retrieve all lands currently posted for sale.  Lands owned by
 * the requesting user are excluded from the result.  Under the
 * chaincode, sale price is stored in the `askingPrice` field.
 *
 * @param string $user_id Current user's identifier
 * @return array
 */
function getAvailableLandsForSale($user_id) {
    $resp = callAPI('POST', API_BASE_URL . '/api/query', [
        'fcn'  => 'queryAvailableLand',
        'args' => [],
    ]);
    if (!$resp || empty($resp['ok'])) {
        return [];
    }
    $lands = $resp['result'];
    // exclude own lands
    return array_values(array_filter($lands, function ($l) use ($user_id) {
        return isset($l['ownerId']) && $l['ownerId'] !== $user_id;
    }));
}

/**
 * Retrieve all lands available for mortgage.  Uses a dedicated
 * endpoint that wraps the `queryAvailableForMortgage` chaincode function.
 *
 * @param string $user_id Current user's identifier
 * @return array
 */
function getAvailableLandsForMortgage($user_id) {
    $resp = callAPI('GET', API_BASE_URL . '/api/availableMortgage');
    if (!$resp || empty($resp['ok'])) {
        return [];
    }
    $lands = $resp['result'];
    return array_values(array_filter($lands, function ($l) use ($user_id) {
        return isset($l['ownerId']) && $l['ownerId'] !== $user_id;
    }));
}

/**
 * Retrieve all lands available for lease.  Uses a dedicated
 * endpoint that wraps the `queryAvailableForLease` chaincode function.
 *
 * @param string $user_id Current user's identifier
 * @return array
 */
function getAvailableLandsForLease($user_id) {
    $resp = callAPI('GET', API_BASE_URL . '/api/availableLease');
    if (!$resp || empty($resp['ok'])) {
        return [];
    }
    $lands = $resp['result'];
    return array_values(array_filter($lands, function ($l) use ($user_id) {
        return isset($l['ownerId']) && $l['ownerId'] !== $user_id;
    }));
}

/**
 * Lands where the current user holds an active mortgage (i.e. they
 * have lent money against somebody else's land).  We derive this by
 * iterating over the user's owned lands and selecting those with
 * an active mortgage entry.
 *
 * @param string $user_id
 * @return array
 */
function getUserMortgageLands($user_id) {
    $lands = getUserLands($user_id);
    $out   = [];
    foreach ($lands as $land) {
        if (isset($land['mortgage']) && isset($land['mortgage']['status']) && $land['mortgage']['status'] === 'Active') {
            $out[] = $land;
        }
    }
    return $out;
}

/**
 * Lands where the current user has an active lease (i.e. they are
 * temporarily renting somebody else's land).  We derive this by
 * iterating over the user's owned lands and selecting those with
 * an active lease entry.
 *
 * @param string $user_id
 * @return array
 */
function getUserLeaseLands($user_id) {
    $lands = getUserLands($user_id);
    $out   = [];
    foreach ($lands as $land) {
        if (isset($land['lease']) && isset($land['lease']['status']) && $land['lease']['status'] === 'Active') {
            $out[] = $land;
        }
    }
    return $out;
}

// The following two helpers were part of the original MySQL-based
// implementation and related to scheduled payments.  The chaincode
// does not implement an equivalent concept at present, so these
// functions simply return empty arrays to avoid breaking the UI.
function getMortgagePaymentLands($link, $user_id) {
    return [];
}

function getLeasePaymentLands($link, $user_id) {
    return [];
}

?>
