<?php
require_once "config.php";

// Only allow logged in non-admin users to view their dashboard
if (!isLoggedIn() || isAdmin()) {
    header("location: login.php");
    exit;
}

$user_id = $_SESSION["id"];

// -----------------------------------------------------------------------------
// Fetch data from the blockchain via helper functions.  The helper functions
// defined in config.php already wrap the necessary API calls.  We intentionally
// avoid any MySQL usage here.

// Lands owned by the current user
$user_lands = getUserLands($user_id);

// Lands currently posted for sale (excluding the user's own lands)
$available_lands = getAvailableLandsForSale($user_id);

// Lands available to mortgage (status == MortgagePending)
$available_mortgage_lands = getAvailableLandsForMortgage($user_id);

// Lands available to lease (status == LeasePending)
$available_lease_lands = getAvailableLandsForLease($user_id);

// In this simplified blockchain implementation the following helpers return
// empty arrays because there is no notion of the user being a temporary
// mortgagee or lessee on someone else's land.  They are retained for
// compatibility with the UI.
$user_mortgage_lands = getUserMortgageLands($user_id);
$user_lease_lands    = getUserLeaseLands($user_id);

// Scheduled payment functionality is not implemented on the ledger, so these
// always return empty arrays.
$mortgage_payment_lands = getMortgagePaymentLands(null, $user_id);
$lease_payment_lands    = getLeasePaymentLands(null, $user_id);

// -----------------------------------------------------------------------------
// Enrich available lists with owner names and more human‑readable fields.  The
// blockchain only stores ownerId and a JSON object for location.  We decode
// those here for display.

/**
 * Fetch the human‑readable name for a given user identifier by querying
 * the ledger via the REST API.  Falls back to the userId itself if
 * personal details are not available.
 *
 * @param string $id
 * @return string
 */
function lookupOwnerName($id) {
    $resp = callAPI('GET', API_BASE_URL . '/api/users/' . urlencode($id));
    if ($resp && !empty($resp['ok'])) {
        $details = $resp['result']['personalDetails'];
        if (is_string($details)) {
            $decoded = json_decode($details, true);
            if (is_array($decoded) && isset($decoded['name'])) {
                return $decoded['name'];
            }
        }
    }
    return $id;
}

/**
 * Normalise a land record from the ledger for presentation.  It adds
 * locationString, area, deed_hash (if embedded in the location object), price,
 * ipfs_cid and owner_name fields.  The original array is modified by
 * reference.
 *
 * @param array $land
 * @param bool  $needOwner Whether to fetch the owner name
 * @return array
 */
function enrichLand(array $land, $needOwner = false) {
    // Decode the location object if provided
    $loc = isset($land['location']) ? $land['location'] : '';
    $locationString = '';
    $area = '';
    $deedHash = '';
    if (is_array($loc)) {
        $locationString = isset($loc['location']) ? $loc['location'] : '';
        $area           = isset($loc['area']) ? $loc['area'] : '';
        $deedHash       = isset($loc['deed_hash']) ? $loc['deed_hash'] : '';
    } else {
        $locationString = $loc;
    }
    $land['locationString'] = $locationString;
    $land['area'] = $area;
    $land['deed_hash'] = $deedHash;
    $land['price'] = isset($land['askingPrice']) ? $land['askingPrice'] : 0;
    $land['ipfs_cid'] = isset($land['deedCid']) ? $land['deedCid'] : '';
    if ($needOwner && isset($land['ownerId'])) {
        $land['owner_name'] = lookupOwnerName($land['ownerId']);
    }
    return $land;
}

// Enrich user lands; we do not need owner name because the owner is the current user
foreach ($user_lands as $idx => $l) {
    $user_lands[$idx] = enrichLand($l, false);
}
// Enrich available sale lands with owner names
foreach ($available_lands as $idx => $l) {
    $available_lands[$idx] = enrichLand($l, true);
}
// Enrich available mortgage lands
foreach ($available_mortgage_lands as $idx => $l) {
    $tmp = enrichLand($l, true);
    // Pull mortgage principal and duration from the embedded mortgage object
    $tmp['mortgage_principal'] = isset($tmp['mortgage']['principal']) ? $tmp['mortgage']['principal'] : 0;
    $tmp['mortgage_duration']  = isset($tmp['mortgage']['duration']) ? $tmp['mortgage']['duration'] : 0;
    $available_mortgage_lands[$idx] = $tmp;
}
// Enrich available lease lands
foreach ($available_lease_lands as $idx => $l) {
    $tmp = enrichLand($l, true);
    // Pull lease rent and duration from the embedded lease object
    $tmp['lease_rent']     = isset($tmp['lease']['rent']) ? $tmp['lease']['rent'] : 0;
    $tmp['lease_duration'] = isset($tmp['lease']['duration']) ? $tmp['lease']['duration'] : 0;
    $available_lease_lands[$idx] = $tmp;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - Land Administration System</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1><i class="fas fa-tachometer-alt"></i> User Dashboard</h1>
                <div class="user-info">
                    <div class="user-welcome">
                        <i class="fas fa-user-circle"></i>
                        <span>Welcome, <?php echo $_SESSION["name"]; ?></span>
                    </div>
                    <div class="user-actions">
                        <a href="profile.php" class="btn btn-outline"><i class="fas fa-user"></i> Profile</a>
                        <a href="logout.php" class="btn btn-outline"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>
        </header>
        
        <div class="dashboard-summary">
            <div class="summary-card">
                <div class="summary-icon">
                    <i class="fas fa-landmark"></i>
                </div>
                <div class="summary-content">
                    <h3><?php echo count($user_lands); ?></h3>
                    <p>Total Lands</p>
                </div>
            </div>
            <div class="summary-card">
                <div class="summary-icon">
                    <i class="fas fa-hand-holding-usd"></i>
                </div>
                <div class="summary-content">
                    <h3><?php echo count(array_filter($user_lands, function($land) { return $land['status'] == 'ForSale' || $land['status'] == 'PendingSale'; })); ?></h3>
                    <p>Lands for Sale</p>
                </div>
            </div>
            <div class="summary-card">
                <div class="summary-icon">
                    <i class="fas fa-file-contract"></i>
                </div>
                <div class="summary-content">
                    <h3><?php echo count($user_mortgage_lands); ?></h3>
                    <p>Mortgaged Lands (Temporary)</p>
                </div>
            </div>
            <div class="summary-card">
                <div class="summary-icon">
                    <i class="fas fa-file-signature"></i>
                </div>
                <div class="summary-content">
                    <h3><?php echo count($user_lease_lands); ?></h3>
                    <p>Leased Lands (Temporary)</p>
                </div>
            </div>
        </div>
        
        <div class="dashboard-tabs">
            <button class="tab-btn active" onclick="openTab('my-lands')"><i class="fas fa-landmark"></i> My Lands</button>
            <button class="tab-btn" onclick="openTab('available-lands')"><i class="fas fa-shopping-cart"></i> Available Lands for Buy</button>
            <button class="tab-btn" onclick="openTab('available-mortgage')"><i class="fas fa-hand-holding-usd"></i> Available for Mortgage</button>
            <button class="tab-btn" onclick="openTab('available-lease')"><i class="fas fa-file-signature"></i> Available for Lease</button>
            <button class="tab-btn" onclick="openTab('mortgage-payment')"><i class="fas fa-credit-card"></i> Pay for Mortgage</button>
            <button class="tab-btn" onclick="openTab('lease-payment')"><i class="fas fa-money-bill-wave"></i> Pay for Lease</button>
            <a href="add_land.php" class="btn btn-primary"><i class="fas fa-plus"></i> Add New Land</a>
        </div>
        
        <div class="dashboard-content">
            <div id="my-lands" class="tab-content active">
                <h2><i class="fas fa-landmark"></i> My Land Assets</h2>
                <?php if (count($user_lands) > 0): ?>
                    <div class="card-container">
                        <?php foreach ($user_lands as $land): ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3><?php echo htmlspecialchars($land['locationString']); ?></h3>
                                    <span class="status-badge status-<?php echo strtolower($land['status']); ?>"><?php echo $land['status']; ?></span>
                                </div>
                                <div class="card-body">
                                    <p><strong>Area:</strong> <?php echo htmlspecialchars($land['area']); ?> sq ft</p>
                                    <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo htmlspecialchars($land['ipfs_cid']); ?></span></p>
                                    <?php if (!empty($land['deed_hash'])): ?>
                                        <p><strong>Deed Hash:</strong> <span class="monospace"><?php echo htmlspecialchars($land['deed_hash']); ?></span></p>
                                    <?php endif; ?>
                                    <?php if ($land['price']): ?>
                                        <p><strong>Asking Price:</strong> ৳<?php echo number_format($land['price'], 2); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="card-actions">
                                    <?php if ($land['status'] === 'Owned'): ?>
                                        <a href="buy_land.php?action=sell&land_id=<?php echo urlencode($land['landId']); ?>" class="btn btn-secondary"><i class="fas fa-tag"></i> Sell</a>
                                        <a href="mortgage.php?land_id=<?php echo urlencode($land['landId']); ?>" class="btn btn-secondary"><i class="fas fa-hand-holding-usd"></i> Mortgage</a>
                                        <a href="lease.php?land_id=<?php echo urlencode($land['landId']); ?>" class="btn btn-secondary"><i class="fas fa-file-signature"></i> Lease</a>
                                    <?php elseif ($land['status'] === 'ForSale' || $land['status'] === 'PendingSale'): ?>
                                        <a href="buy_land.php?action=cancel&land_id=<?php echo urlencode($land['landId']); ?>" class="btn btn-warning"><i class="fas fa-times-circle"></i> Cancel Sale</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-landmark"></i>
                        <h3>No Land Assets</h3>
                        <p>You don't have any land assets registered. <a href="add_land.php">Add your first land</a>.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div id="available-lands" class="tab-content">
                <h2><i class="fas fa-shopping-cart"></i> Available Lands for Sale</h2>
                <?php if (count($available_lands) > 0): ?>
                    <div class="card-container">
                        <?php foreach ($available_lands as $land): ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3><?php echo htmlspecialchars($land['locationString']); ?></h3>
                                    <span class="status-badge status-forsale">For Sale</span>
                                </div>
                                <div class="card-body">
                                    <p><strong>Area:</strong> <?php echo htmlspecialchars($land['area']); ?> sq ft</p>
                                    <p><strong>Price:</strong> ৳<?php echo number_format($land['price'], 2); ?></p>
                                    <p><strong>Owner:</strong> <?php echo htmlspecialchars($land['owner_name']); ?></p>
                                    <?php if (!empty($land['ipfs_cid'])): ?>
                                        <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo htmlspecialchars($land['ipfs_cid']); ?></span></p>
                                    <?php endif; ?>
                                </div>
                                <div class="card-actions">
                                    <a href="buy_land.php?action=buy&land_id=<?php echo urlencode($land['landId']); ?>" class="btn btn-primary"><i class="fas fa-shopping-cart"></i> Buy This Land</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-shopping-cart"></i>
                        <h3>No Lands Available</h3>
                        <p>No lands available for sale at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div id="available-mortgage" class="tab-content">
                <h2><i class="fas fa-hand-holding-usd"></i> Available Lands for Mortgage</h2>
                <?php if (count($available_mortgage_lands) > 0): ?>
                    <div class="card-container">
                        <?php foreach ($available_mortgage_lands as $land): ?>
                            <div class="card">
                                <div class="card-header">
                                </div>
                                <div class="card-body">
                                    <h3><?php echo htmlspecialchars($land['locationString']); ?></h3>
                                    <span class="status-badge status-formortgage">For Mortgage</span>
                                    <p><strong>Area:</strong> <?php echo htmlspecialchars($land['area']); ?> sq ft</p>
                                    <p><strong>Mortgage Amount:</strong> ৳<?php echo number_format($land['mortgage_principal'], 2); ?></p>
                                    <p><strong>Duration:</strong> <?php echo $land['mortgage_duration']; ?> months</p>
                                    <p><strong>Owner:</strong> <?php echo htmlspecialchars($land['owner_name']); ?></p>
                                    <?php if (!empty($land['ipfs_cid'])): ?>
                                        <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo htmlspecialchars($land['ipfs_cid']); ?></span></p>
                                    <?php endif; ?>
                                </div>
                                <div class="card-actions">
                                    <a href="accept_mortgage.php?land_id=<?php echo urlencode($land['landId']); ?>" class="btn btn-primary"><i class="fas fa-handshake"></i> Accept Mortgage</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-hand-holding-usd"></i>
                        <h3>No Lands Available</h3>
                        <p>No lands available for mortgage at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div id="available-lease" class="tab-content">
                <h2><i class="fas fa-file-signature"></i> Available Lands for Lease</h2>
                <?php if (count($available_lease_lands) > 0): ?>
                    <div class="card-container">
                        <?php foreach ($available_lease_lands as $land): ?>
                            <div class="card">
                                <div class="card-header">
                                </div>
                                <div class="card-body">
                                    <h3><?php echo htmlspecialchars($land['locationString']); ?></h3>
                                    <span class="status-badge status-forlease">For Lease</span>
                                    <p><strong>Area:</strong> <?php echo htmlspecialchars($land['area']); ?> sq ft</p>
                                    <p><strong>Monthly Rent:</strong> ৳<?php echo number_format($land['lease_rent'], 2); ?></p>
                                    <p><strong>Duration:</strong> <?php echo $land['lease_duration']; ?> months</p>
                                    <p><strong>Owner:</strong> <?php echo htmlspecialchars($land['owner_name']); ?></p>
                                    <?php if (!empty($land['ipfs_cid'])): ?>
                                        <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo htmlspecialchars($land['ipfs_cid']); ?></span></p>
                                    <?php endif; ?>
                                </div>
                                <div class="card-actions">
                                    <a href="accept_lease.php?land_id=<?php echo urlencode($land['landId']); ?>" class="btn btn-primary"><i class="fas fa-file-signature"></i> Accept Lease</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-file-signature"></i>
                        <h3>No Lands Available</h3>
                        <p>No lands available for lease at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div id="mortgage-payment" class="tab-content">
                <h2><i class="fas fa-credit-card"></i> Pay for Mortgage</h2>
                <?php if (count($mortgage_payment_lands) > 0): ?>
                    <div class="card-container">
                        <?php foreach ($mortgage_payment_lands as $land): ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3><?php echo $land['location']; ?></h3>
                                    <span class="status-badge status-mortgaged">Mortgaged</span>
                                </div>
                                <div class="card-body">
                                    <p><strong>Area:</strong> <?php echo $land['area']; ?> sq ft</p>
                                    <p><strong>Mortgage Amount:</strong> ৳<?php echo number_format($land['amount'], 2); ?></p>
                                    <p><strong>Due Date:</strong> <?php echo $land['end_date']; ?></p>
                                    <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo $land['ipfs_cid']; ?></span></p>
                                    <p><strong>Deed Hash:</strong> <span class="monospace"><?php echo $land['deed_hash']; ?></span></p>
                                </div>
                                <div class="card-actions">
                                    <a href="pay_mortgage.php?land_id=<?php echo $land['id']; ?>" class="btn btn-primary"><i class="fas fa-credit-card"></i> Make Payment</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-credit-card"></i>
                        <h3>No Mortgage Payments Due</h3>
                        <p>You don't have any mortgaged lands to pay for at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div id="lease-payment" class="tab-content">
                <h2><i class="fas fa-money-bill-wave"></i> Pay for Lease</h2>
                <?php if (count($lease_payment_lands) > 0): ?>
                    <div class="card-container">
                        <?php foreach ($lease_payment_lands as $land): ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3><?php echo $land['location']; ?></h3>
                                    <span class="status-badge status-leased">Leased</span>
                                </div>
                                <div class="card-body">
                                    <p><strong>Area:</strong> <?php echo $land['area']; ?> sq ft</p>
                                    <p><strong>Monthly Payment:</strong> ৳<?php echo number_format($land['monthly_payment'], 2); ?></p>
                                    <p><strong>Due Date:</strong> <?php echo $land['end_date']; ?></p>
                                    <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo $land['ipfs_cid']; ?></span></p>
                                    <p><strong>Deed Hash:</strong> <span class="monospace"><?php echo $land['deed_hash']; ?></span></p>
                                </div>
                                <div class="card-actions">
                                    <a href="pay_lease.php?land_id=<?php echo $land['id']; ?>" class="btn btn-primary"><i class="fas fa-money-bill-wave"></i> Make Payment</a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-money-bill-wave"></i>
                        <h3>No Lease Payments Due</h3>
                        <p>You don't have any leased lands to pay for at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function openTab(tabName) {
            // Hide all tab contents
            var tabContents = document.getElementsByClassName("tab-content");
            for (var i = 0; i < tabContents.length; i++) {
                tabContents[i].classList.remove("active");
            }
            
            // Remove active class from all buttons
            var tabButtons = document.getElementsByClassName("tab-btn");
            for (var i = 0; i < tabButtons.length; i++) {
                tabButtons[i].classList.remove("active");
            }
            
            // Show the selected tab and mark button as active
            document.getElementById(tabName).classList.add("active");
            event.currentTarget.classList.add("active");
        }
    </script>
    <script src="js/script.js"></script>
</body>
</html>
