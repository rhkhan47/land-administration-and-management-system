<?php
require_once "config.php";

// Only allow logged in non-admin users
if (!isLoggedIn() || isAdmin()) {
    header("location: login.php");
    exit;
}

// Ensure a land_id is provided
if (!isset($_GET['land_id'])) {
    header("location: user_dashboard.php");
    exit;
}

$land_id = $_GET['land_id'];
$user_id = $_SESSION["id"];

// Fetch land details from the ledger
$land = null;
$resp = callAPI('POST', API_BASE_URL . '/api/query', [
    'fcn'  => 'readLand',
    'args' => [$land_id]
]);
if ($resp && !empty($resp['ok'])) {
    $land = $resp['result'];
}
// Ensure land has a pending lease
if (!$land || !isset($land['lease']) || $land['lease']['status'] !== 'Pending') {
    header("location: user_dashboard.php");
    exit;
}

// Fetch owner name for display
$ownerResp = callAPI('GET', API_BASE_URL . '/api/users/' . urlencode($land['ownerId']));
$ownerName = $land['ownerId'];
if ($ownerResp && !empty($ownerResp['ok'])) {
    $pd = $ownerResp['result']['personalDetails'];
    if (is_string($pd)) {
        $pdArr = json_decode($pd, true);
        if (is_array($pdArr) && isset($pdArr['name'])) {
            $ownerName = $pdArr['name'];
        }
    }
}
// Derive human‑readable fields
$loc = $land['location'];
if (is_array($loc)) {
    $land['locationString'] = isset($loc['location']) ? $loc['location'] : '';
    $land['area'] = isset($loc['area']) ? $loc['area'] : '';
} else {
    $land['locationString'] = $loc;
    $land['area'] = '';
}
// Extract optional deed hash and IPFS CID for display
$land['ipfs_cid'] = isset($land['deedCid']) ? $land['deedCid'] : '';
// If the location object contains a deed hash, extract it
$deedHash = '';
if (is_array($loc) && isset($loc['deed_hash'])) {
    $deedHash = $loc['deed_hash'];
}
$land['deed_hash'] = $deedHash;
$land['owner_name'] = $ownerName;
$land['leaseRent'] = isset($land['lease']['rent']) ? $land['lease']['rent'] : 0;
$land['leaseDuration'] = isset($land['lease']['duration']) ? $land['lease']['duration'] : 0;

// Handle acceptance on POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $payload = [
        'fcn'  => 'acceptLease',
        'args' => [$land_id, $user_id]
    ];
    $invResp = callAPI('POST', API_BASE_URL . '/api/invoke', $payload);
    if ($invResp && !empty($invResp['ok'])) {
        header("location: user_dashboard.php?lease_requested=1");
        exit;
    } else {
        $error = isset($invResp['error']) ? $invResp['error'] : "Error processing lease request.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accept Lease - Land Administration System</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1><i class="fas a-file-signature"></i> Accept Lease</h1>
                <div class="user-info">
                    <a href="user_dashboard.php" class="btn btn-outline"><i class="fas a-arrow-left"></i> Back to Dashboard</a>
                    <a href="logout.php" class="btn btn-outline"><i class="fas a-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </header>
        
        <div class="form-wrapper">
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas a-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="land-details">
                <h3>Land Details</h3>
                <p><strong>Location:</strong> <?php echo htmlspecialchars($land['locationString']); ?></p>
                <p><strong>Area:</strong> <?php echo htmlspecialchars($land['area']); ?> sq ft</p>
                <p><strong>Owner:</strong> <?php echo htmlspecialchars($land['owner_name']); ?></p>
                <p><strong>Monthly Rent:</strong> ৳<?php echo number_format($land['leaseRent'], 2); ?></p>
                <p><strong>Duration:</strong> <?php echo $land['leaseDuration']; ?> months</p>
                <p><strong>Total Lease Amount:</strong> ৳<?php echo number_format($land['leaseRent'] * $land['leaseDuration'], 2); ?></p>
                <?php if (!empty($land['ipfs_cid'])): ?>
                    <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo htmlspecialchars($land['ipfs_cid']); ?></span></p>
                <?php endif; ?>
                <?php if (!empty($land['deed_hash'])): ?>
                    <p><strong>Deed Hash:</strong> <span class="monospace"><?php echo htmlspecialchars($land['deed_hash']); ?></span></p>
                <?php endif; ?>
            </div>

            <form method="post">
                <div class="form-group">
                    <p>By clicking "Accept Lease", you agree to lease this land for ৳<?php echo number_format($land['leaseRent'], 2); ?> per month for <?php echo $land['leaseDuration']; ?> months.</p>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary"><i class="fas a-file-signature"></i> Accept Lease</button>
                    <a href="user_dashboard.php" class="btn btn-default">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>
