<?php
require_once "config.php";

// Only authenticated administrators may view this page
if (!isLoggedIn() || !isAdmin()) {
    header("location: login.php");
    exit;
}

// Fetch pending users from the ledger.  The API wraps the
// `queryPendingUsers` chaincode function.  Each returned user
// contains a personalDetails field that we decode to populate
// additional columns.
$pending_users = [];
$resp_users = callAPI('GET', API_BASE_URL . '/api/pendingUsers');
if ($resp_users && !empty($resp_users['ok'])) {
    foreach ($resp_users['result'] as $u) {
        $details = $u['personalDetails'];
        if (is_string($details)) {
            $decoded = json_decode($details, true);
            $details = is_array($decoded) ? $decoded : [];
        }
        $pending_users[] = [
            'userId'            => $u['userId'],
            'name'              => isset($details['name']) ? $details['name'] : $u['userId'],
            'national_id'       => isset($u['nationalId']) ? $u['nationalId'] : '',
            'email'             => isset($details['email']) ? $details['email'] : '',
            'dob'               => isset($details['dob']) ? $details['dob'] : '',
            'permanent_address' => isset($details['permanent_address']) ? $details['permanent_address'] : '',
            'created_at'        => '' // creation timestamp not tracked in this demo
        ];
    }
}

// Fetch pending lands awaiting inspector approval.  The API wraps
// the `queryPendingLand` chaincode function.  We leave other land
// lists (Owned/ForSale) out of the admin view as they are not
// relevant to approval.
$pending_lands = [];
$resp_lands = callAPI('GET', API_BASE_URL . '/api/pendingLand');
if ($resp_lands && !empty($resp_lands['ok'])) {
    $pending_lands = $resp_lands['result'];
}

// Handle form submissions.  For each action we invoke a
// corresponding chaincode function via the generic invoke endpoint.
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Approve a user
    if (isset($_POST["approve_user"])) {
        $user_id = $_POST["user_id"];
        callAPI('POST', API_BASE_URL . '/api/invoke', [
            'fcn'  => 'approveUser',
            'args' => [$user_id]
        ]);
        header("location: admin_dashboard.php");
        exit;
    }
    // Approve a land
    if (isset($_POST["approve_land"])) {
        $land_id = $_POST["land_id"];
        callAPI('POST', API_BASE_URL . '/api/invoke', [
            'fcn'  => 'approveLand',
            'args' => [$land_id]
        ]);
        header("location: admin_dashboard.php");
        exit;
    }
    // No explicit reject operations exist in the chaincode; simply
    // reload the page if a reject action was attempted.
    if (isset($_POST["reject_user"]) || isset($_POST["reject_land"])) {
        header("location: admin_dashboard.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Land Administration System</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1><i class="fas fa-cogs"></i> Land Inspector Dashboard</h1>
                <div class="user-info">
                    <div class="user-welcome">
                        <i class="fas fa-user-circle"></i>
                        <span>Welcome, <?php echo $_SESSION["name"]; ?></span>
                    </div>
                    <div class="user-actions">
                        <a href="logout.php" class="btn btn-outline"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>
        </header>
        
        <div class="dashboard-tabs">
            <button class="tab-btn active" onclick="openTab('pending-users')"><i class="fas fa-users"></i> Pending Users</button>
            <button class="tab-btn" onclick="openTab('pending-land')"><i class="fas fa-landmark"></i> Pending Land</button>
        </div>
        
        <div class="dashboard-content">
            <div id="pending-users" class="tab-content active">
                <h2><i class="fas fa-users"></i> Pending User Approvals</h2>
                <?php if (count($pending_users) > 0): ?>
                    <div class="card-container">
                        <?php foreach ($pending_users as $user): ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3><?php echo $user['name']; ?></h3>
                                    <span class="status-badge status-pending">Pending</span>
                                </div>
                                <div class="card-body">
                                    <p><strong>National ID:</strong> <?php echo $user['national_id']; ?></p>
                                    <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
                                    <p><strong>Date of Birth:</strong> <?php echo $user['dob']; ?></p>
                                    <p><strong>Permanent Address:</strong> <?php echo $user['permanent_address']; ?></p>
                                    <p><strong>Registration Date:</strong> <?php echo $user['created_at']; ?></p>
                                </div>
                                <div class="card-actions">
                                    <form method="post" style="display: inline;">
                                    <input type="hidden" name="user_id" value="<?php echo $user['userId']; ?>">
                                        <button type="submit" name="approve_user" class="btn btn-success"><i class="fas fa-check"></i> Approve</button>
                                    </form>
                                    <form method="post" style="display: inline;">
                                    <input type="hidden" name="user_id" value="<?php echo $user['userId']; ?>">
                                        <button type="submit" name="reject_user" class="btn btn-danger"><i class="fas fa-times"></i> Reject</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-users"></i>
                        <h3>No Pending Users</h3>
                        <p>No pending user approvals at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div id="pending-land" class="tab-content">
                <h2><i class="fas fa-landmark"></i> Pending Land Approvals</h2>
                <?php if (count($pending_lands) > 0): ?>
                    <div class="card-container">
                        <?php foreach ($pending_lands as $land): ?>
                            <div class="card">
                                <div class="card-header">
                                    <h3>Land #<?php echo htmlspecialchars($land['landId']); ?></h3>
                                    <span class="status-badge status-pending">Pending</span>
                                </div>
                                <div class="card-body">
                                    <p><strong>Location:</strong> <?php echo is_array($land['location']) ? json_encode($land['location']) : htmlspecialchars($land['location']); ?></p>
                                    <p><strong>Owner:</strong> <?php echo htmlspecialchars($land['ownerId']); ?></p>
                                    <p><strong>Status:</strong> <?php echo htmlspecialchars($land['status']); ?></p>
                                    <?php if (isset($land['askingPrice']) && $land['askingPrice'] > 0): ?>
                                        <p><strong>Asking Price:</strong> ৳<?php echo number_format($land['askingPrice'], 2); ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="card-actions">
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="land_id" value="<?php echo htmlspecialchars($land['landId']); ?>">
                                        <button type="submit" name="approve_land" class="btn btn-success"><i class="fas fa-check"></i> Approve</button>
                                    </form>
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="land_id" value="<?php echo htmlspecialchars($land['landId']); ?>">
                                        <button type="submit" name="reject_land" class="btn btn-danger"><i class="fas fa-times"></i> Reject</button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="fas fa-landmark"></i>
                        <h3>No Pending Land</h3>
                        <p>No pending land approvals at the moment.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        function openTab(tabName) {
            // Hide all tab contents
            var tabContents = document.getElementsByClassName("tab-content");
            for (var i = 0; i < tabContents.length; i++) {
                tabContents[i].classList.remove("active");
            }
            
            // Remove active class from all buttons
            var tabButtons = document.getElementsByClassName("tab-btn");
            for (var i = 0; i < tabButtons.length; i++) {
                tabButtons[i].classList.remove("active");
            }
            
            // Show the selected tab and mark button as active
            document.getElementById(tabName).classList.add("active");
            event.currentTarget.classList.add("active");
        }
    </script>
    <script src="js/script.js"></script>
</body>
</html>
