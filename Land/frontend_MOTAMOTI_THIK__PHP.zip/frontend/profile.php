<?php
require_once "config.php";

// Ensure the user is logged in
if (!isLoggedIn()) {
    header("location: login.php");
    exit;
}

// The user identifier on the ledger matches the session id
$user_id = $_SESSION["id"];

// Fetch the user details from the ledger via the API
$user = null;
$resp = callAPI('GET', API_BASE_URL . '/api/users/' . urlencode($user_id));
if ($resp && !empty($resp['ok'])) {
    $user = $resp['result'];
}

// Decode the personalDetails JSON into an array
$details = [];
if ($user && isset($user['personalDetails'])) {
    $pd = $user['personalDetails'];
    if (is_string($pd)) {
        $pdArr = json_decode($pd, true);
        if (is_array($pdArr)) {
            $details = $pdArr;
        }
    } elseif (is_array($pd)) {
        $details = $pd;
    }
}

// Extract fields for display with sensible defaults
$name        = isset($details['name']) ? $details['name'] : $user_id;
$email       = isset($details['email']) ? $details['email'] : '';
$national_id = isset($details['national_id']) ? $details['national_id'] : '';
$dob         = isset($details['dob']) ? $details['dob'] : '';
$permanent_address = isset($details['permanent_address']) ? $details['permanent_address'] : '';
$status      = isset($user['status']) ? $user['status'] : '';
$user_type   = isset($details['user_type']) ? $details['user_type'] : 'User';
$created_at  = '';

// Note: Profile updates are not supported in this blockchain demo.  The form is read‑only.
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - Land Administration System</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1><i class="fas a-user"></i> User Profile</h1>
                <div class="user-info">
                    <div class="user-welcome">
                        <i class="fas a-user-circle"></i>
                        <span>Welcome, <?php echo $_SESSION["name"]; ?></span>
                    </div>
                    <div class="user-actions">
                        <a href="<?php echo isAdmin() ? 'admin_dashboard.php' : 'user_dashboard.php'; ?>" class="btn btn-outline"><i class="fas a-arrow-left"></i> Back to Dashboard</a>
                        <a href="logout.php" class="btn btn-outline"><i class="fas a-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>
        </header>
        
        <div class="form-wrapper">
            <div class="alert alert-info">
                <i class="fas a-info-circle"></i> Profile information is read‑only in this demo.
            </div>
            
            <div class="profile-details">
                <div class="form-group">
                    <label>Full Name</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas a-user"></i></span>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($name); ?>" disabled>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Email</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas a-envelope"></i></span>
                        <input type="email" class="form-control" value="<?php echo htmlspecialchars($email); ?>" disabled>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>National ID</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas a-id-card"></i></span>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($national_id); ?>" disabled>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Date of Birth</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas a-calendar"></i></span>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($dob); ?>" disabled>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Permanent Address</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas a-home"></i></span>
                        <textarea class="form-control" rows="3" disabled><?php echo htmlspecialchars($permanent_address); ?></textarea>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Account Status</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas a-info-circle"></i></span>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($status); ?>" disabled>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>User Type</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas a-user-tag"></i></span>
                        <input type="text" class="form-control" value="<?php echo htmlspecialchars($user_type); ?>" disabled>
                    </div>
                </div>
                
                <div class="form-group">
                    <a href="<?php echo isAdmin() ? 'admin_dashboard.php' : 'user_dashboard.php'; ?>" class="btn btn-default"><i class="fas a-arrow-left"></i> Back to Dashboard</a>
                </div>
            </div>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>
