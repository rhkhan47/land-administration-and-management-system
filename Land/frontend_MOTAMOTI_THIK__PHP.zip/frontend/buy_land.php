<?php
require_once "config.php";

// Only allow logged in non-admin users
if (!isLoggedIn() || isAdmin()) {
    header("location: login.php");
    exit;
}

// Validate request parameters
if (!isset($_GET['land_id']) || !isset($_GET['action'])) {
    header("location: user_dashboard.php");
    exit;
}

$land_id = $_GET['land_id'];
$action  = $_GET['action'];
$user_id = $_SESSION["id"];

// Fetch land details from the ledger
$land = null;
$resp = callAPI('POST', API_BASE_URL . '/api/query', [
    'fcn'  => 'readLand',
    'args' => [$land_id]
]);
if ($resp && !empty($resp['ok'])) {
    $land = $resp['result'];
    // Derive human‑readable fields
    $loc = $land['location'];
    if (is_array($loc)) {
        $land['locationString'] = isset($loc['location']) ? $loc['location'] : '';
        $land['area'] = isset($loc['area']) ? $loc['area'] : '';
        $land['deed_hash'] = isset($loc['deed_hash']) ? $loc['deed_hash'] : '';
    } else {
        $land['locationString'] = $loc;
        $land['area'] = '';
        $land['deed_hash'] = '';
    }
    $land['price'] = isset($land['askingPrice']) ? $land['askingPrice'] : 0;
    $land['ipfs_cid'] = isset($land['deedCid']) ? $land['deedCid'] : '';
    // Lookup owner name
    $ownerResp = callAPI('GET', API_BASE_URL . '/api/users/' . urlencode($land['ownerId']));
    $ownerName = $land['ownerId'];
    if ($ownerResp && !empty($ownerResp['ok'])) {
        $pd = $ownerResp['result']['personalDetails'];
        if (is_string($pd)) {
            $pdArr = json_decode($pd, true);
            if (is_array($pdArr) && isset($pdArr['name'])) {
                $ownerName = $pdArr['name'];
            }
        }
    }
    $land['owner_name'] = $ownerName;
}
// If land could not be fetched, redirect back
if (!$land) {
    header("location: user_dashboard.php");
    exit;
}

// Messages for user feedback
$message = "";
$error   = "";

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($action == "sell") {
        // Listing the land for sale
        $price = trim($_POST["price"]);
        if (empty($price) || !is_numeric($price)) {
            $error = "Please enter a valid price.";
        } else {
            $payload = [
                'fcn'  => 'postForSale',
                'args' => [$land_id, $price]
            ];
            $resp = callAPI('POST', API_BASE_URL . '/api/invoke', $payload);
            if ($resp && !empty($resp['ok'])) {
                $message = "Land listed for sale successfully!";
                // Refresh land data to reflect new status
                $land['status'] = 'ForSale';
                $land['price'] = floatval($price);
            } else {
                $error = isset($resp['error']) ? $resp['error'] : "Error listing land for sale.";
            }
        }
    } elseif ($action == "buy") {
        // Submitting a buy request
        $price = trim($_POST["price"]);
        if (empty($price) || !is_numeric($price)) {
            $error = "Invalid price provided.";
        } else {
            $payload = [
                'fcn'  => 'buyRequest',
                'args' => [$land_id, $user_id, $price]
            ];
            $resp = callAPI('POST', API_BASE_URL . '/api/invoke', $payload);
            if ($resp && !empty($resp['ok'])) {
                $message = "Purchase request submitted successfully!";
                // update local status
                $land['status'] = 'PendingSale';
            } else {
                $error = isset($resp['error']) ? $resp['error'] : "Error processing purchase request.";
            }
        }
    } elseif ($action == "cancel") {
        // Cancelling a sale
        $resp = callAPI('POST', API_BASE_URL . '/api/cancelSale', ['landId' => $land_id]);
        if ($resp && !empty($resp['ok'])) {
            $message = "Sale cancelled successfully!";
            $land['status'] = 'Owned';
            $land['price']  = 0;
        } else {
            $error = isset($resp['error']) ? $resp['error'] : "Error cancelling sale.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php 
        if ($action == "buy") echo "Buy Land";
        elseif ($action == "sell") echo "Sell Land";
        elseif ($action == "cancel") echo "Cancel Sale";
        ?> - Land Administration System
    </title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1>
                    <?php 
                    if ($action == "buy") echo "<i class='fas fa-shopping-cart'></i> Buy Land";
                    elseif ($action == "sell") echo "<i class='fas fa-tag'></i> Sell Land";
                    elseif ($action == "cancel") echo "<i class='fas fa-times-circle'></i> Cancel Sale";
                    ?>
                </h1>
                <div class="user-info">
                    <a href="user_dashboard.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                    <a href="logout.php" class="btn btn-outline"><i class="fas a-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </header>
        
        <div class="form-wrapper">
            <?php if (!empty($message)): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $message; ?>
                    <p><a href="user_dashboard.php">Return to Dashboard</a></p>
                </div>
            <?php elseif (!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($_SERVER["REQUEST_METHOD"] != "POST" || !empty($error)): ?>
                <?php if ($action == "buy"): ?>
                    <div class="land-details">
                        <h3>Land Details</h3>
                        <p><strong>Location:</strong> <?php echo htmlspecialchars($land['locationString']); ?></p>
                        <p><strong>Area:</strong> <?php echo htmlspecialchars($land['area']); ?> sq ft</p>
                        <p><strong>Current Owner:</strong> <?php echo htmlspecialchars($land['owner_name']); ?></p>
                        <p><strong>Price:</strong> ৳<?php echo number_format($land['price'], 2); ?></p>
                        <?php if (!empty($land['ipfs_cid'])): ?>
                            <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo htmlspecialchars($land['ipfs_cid']); ?></span></p>
                        <?php endif; ?>
                        <?php if (!empty($land['deed_hash'])): ?>
                            <p><strong>Deed Hash:</strong> <span class="monospace"><?php echo htmlspecialchars($land['deed_hash']); ?></span></p>
                        <?php endif; ?>
                    </div>
                    
                    <form method="post">
                        <input type="hidden" name="price" value="<?php echo $land['price']; ?>">
                        <div class="form-group">
                            <p>By clicking "Confirm Purchase", you agree to buy this land for ৳<?php echo number_format($land['price'], 2); ?>.</p>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary"><i class="fas fa-shopping-cart"></i> Confirm Purchase</button>
                            <a href="user_dashboard.php" class="btn btn-default">Cancel</a>
                        </div>
                    </form>
                
                <?php elseif ($action == "sell"): ?>
                    <div class="land-details">
                        <h3>Your Land Details</h3>
                        <p><strong>Location:</strong> <?php echo htmlspecialchars($land['locationString']); ?></p>
                        <p><strong>Area:</strong> <?php echo htmlspecialchars($land['area']); ?> sq ft</p>
                        <?php if (!empty($land['ipfs_cid'])): ?>
                            <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo htmlspecialchars($land['ipfs_cid']); ?></span></p>
                        <?php endif; ?>
                        <?php if (!empty($land['deed_hash'])): ?>
                            <p><strong>Deed Hash:</strong> <span class="monospace"><?php echo htmlspecialchars($land['deed_hash']); ?></span></p>
                        <?php endif; ?>
                    </div>
                    
                    <form method="post">
                        <div class="form-group">
                            <label>Sale Price (৳)</label>
                            <div class="input-group">
                                <span class="input-icon"><i class="fas fa-tag"></i></span>
                                <input type="number" step="0.01" name="price" class="form-control" value="<?php echo $land['price']; ?>" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary"><i class="fas fa-tag"></i> List for Sale</button>
                            <a href="user_dashboard.php" class="btn btn-default">Cancel</a>
                        </div>
                    </form>
                
                <?php elseif ($action == "cancel"): ?>
                    <div class="land-details">
                        <h3>Land Details</h3>
                        <p><strong>Location:</strong> <?php echo htmlspecialchars($land['locationString']); ?></p>
                        <p><strong>Area:</strong> <?php echo htmlspecialchars($land['area']); ?> sq ft</p>
                        <p><strong>Current Price:</strong> ৳<?php echo number_format($land['price'], 2); ?></p>
                    </div>
                    
                    <form method="post">
                        <div class="form-group">
                            <p>Are you sure you want to cancel the sale of this land?</p>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-warning"><i class="fas fa-times-circle"></i> Cancel Sale</button>
                            <a href="user_dashboard.php" class="btn btn-default">Keep Listed</a>
                        </div>
                    </form>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>
