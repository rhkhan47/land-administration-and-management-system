<?php
require_once "config.php";

// Only allow logged in non-admin users
if (!isLoggedIn() || isAdmin()) {
    header("location: login.php");
    exit;
}

// Ensure a land_id is provided
if (!isset($_GET['land_id'])) {
    header("location: user_dashboard.php");
    exit;
}

$land_id = $_GET['land_id'];
$user_id = $_SESSION["id"];

// Fetch land details to verify ownership and status
$land = null;
$resp = callAPI('POST', API_BASE_URL . '/api/query', [
    'fcn'  => 'readLand',
    'args' => [$land_id]
]);
if ($resp && !empty($resp['ok'])) {
    $land = $resp['result'];
}
// Ensure land exists and belongs to the current user and is owned
if (!$land || $land['ownerId'] !== $user_id || $land['status'] !== 'Owned') {
    header("location: user_dashboard.php");
    exit;
}

$amount = $duration = "";
$amount_err = $duration_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate amount
    if (empty(trim($_POST["amount"])) || !is_numeric($_POST["amount"])) {
        $amount_err = "Please enter a valid amount.";
    } else {
        $amount = trim($_POST["amount"]);
    }
    
    // Validate duration
    if (empty(trim($_POST["duration"])) || !is_numeric($_POST["duration"])) {
        $duration_err = "Please enter a valid duration in months.";
    } else {
        $duration = trim($_POST["duration"]);
    }
    
    // Check input errors before invoking the chaincode
    if (empty($amount_err) && empty($duration_err)) {
        $payload = [
            'fcn'  => 'postMortgage',
            // Escrow address is optional; pass an empty string for now
            'args' => [$land_id, $amount, $duration, '']
        ];
        $invResp = callAPI('POST', API_BASE_URL . '/api/invoke', $payload);
        if ($invResp && !empty($invResp['ok'])) {
            header("location: user_dashboard.php?mortgage_listed=1");
            exit;
        } else {
            echo "Error processing mortgage listing.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mortgage Land - Land Administration System</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1><i class="fas fa-hand-holding-usd"></i> Mortgage Land</h1>
                <div class="user-info">
                    <a href="user_dashboard.php" class="btn btn-outline"><i class="fas a-arrow-left"></i> Back to Dashboard</a>
                    <a href="logout.php" class="btn btn-outline"><i class="fas a-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </header>
        
        <div class="form-wrapper">
            <div class="land-details">
                <h3>Land Details</h3>
                <?php
                    // Derive human‑readable fields for display
                    $loc = $land['location'];
                    if (is_array($loc)) {
                        $locationString = isset($loc['location']) ? $loc['location'] : '';
                        $area = isset($loc['area']) ? $loc['area'] : '';
                    } else {
                        $locationString = $loc;
                        $area = '';
                    }
                    $ipfs = isset($land['deedCid']) ? $land['deedCid'] : '';
                ?>
                <p><strong>Location:</strong> <?php echo htmlspecialchars($locationString); ?></p>
                <p><strong>Area:</strong> <?php echo htmlspecialchars($area); ?> sq ft</p>
                <?php if (!empty($ipfs)): ?>
                    <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo htmlspecialchars($ipfs); ?></span></p>
                <?php endif; ?>
            </div>
            
            <form method="post">
                <div class="form-group <?php echo (!empty($amount_err)) ? 'has-error' : ''; ?>">
                    <label>Mortgage Amount (৳)</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas a-money-bill-wave"></i></span>
                        <input type="number" step="0.01" name="amount" class="form-control" value="<?php echo $amount; ?>">
                    </div>
                    <span class="help-block"><?php echo $amount_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($duration_err)) ? 'has-error' : ''; ?>">
                    <label>Duration (months)</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas a-clock"></i></span>
                        <input type="number" name="duration" class="form-control" value="<?php echo $duration; ?>">
                    </div>
                    <span class="help-block"><?php echo $duration_err; ?></span>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary"><i class="fas a-hand-holding-usd"></i> List for Mortgage</button>
                    <a href="user_dashboard.php" class="btn btn-default">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>
