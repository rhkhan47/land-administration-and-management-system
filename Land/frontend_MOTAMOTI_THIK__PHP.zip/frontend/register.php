<?php
require_once "config.php";

// Redirect already-authenticated users to their dashboard
if (isLoggedIn()) {
    header("location: " . (isAdmin() ? "admin_dashboard.php" : "user_dashboard.php"));
    exit;
}

// Form fields and error holders
$name = $national_id = $email = $password = $confirm_password = $dob = $permanent_address = "";
$name_err = $national_id_err = $email_err = $password_err = $confirm_password_err = $dob_err = $permanent_address_err = "";

// Handle registration submission.  This variant records the new
// user on the Hyperledger Fabric network via the `registerUser`
// chaincode function exposed by the REST API.  The user's email is
// used as their unique identifier (userId) on the ledger, and
// personal details including a password hash are stored in the
// personalDetails field as JSON.
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate name
    if (empty(trim($_POST["name"]))) {
        $name_err = "Please enter your name.";
    } else {
        $name = trim($_POST["name"]);
    }
    
    // Validate national ID
    if (empty(trim($_POST["national_id"]))) {
        $national_id_err = "Please enter your National ID.";
    } else {
        $national_id = trim($_POST["national_id"]);
    }
    
    // Validate email
    if (empty(trim($_POST["email"]))) {
        $email_err = "Please enter an email.";
    } else {
        $email = trim($_POST["email"]);
    }
    
    // Validate date of birth
    if (empty(trim($_POST["dob"]))) {
        $dob_err = "Please enter your date of birth.";
    } else {
        $dob = trim($_POST["dob"]);
    }
    
    // Validate permanent address
    if (empty(trim($_POST["permanent_address"]))) {
        $permanent_address_err = "Please enter your permanent address.";
    } else {
        $permanent_address = trim($_POST["permanent_address"]);
    }
    
    // Validate password
    if (empty(trim($_POST["password"]))) {
        $password_err = "Please enter a password.";     
    } elseif (strlen(trim($_POST["password"])) < 6) {
        $password_err = "Password must have at least 6 characters.";
    } else {
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if (empty(trim($_POST["confirm_password"]))) {
        $confirm_password_err = "Please confirm password.";     
    } else {
        $confirm_password = trim($_POST["confirm_password"]);
        if (empty($password_err) && ($password != $confirm_password)) {
            $confirm_password_err = "Password did not match.";
        }
    }
    
    // Proceed if there are no validation errors
    if (empty($name_err) && empty($national_id_err) && empty($email_err) && empty($password_err) && empty($confirm_password_err) && empty($dob_err) && empty($permanent_address_err)) {
        $userId = $email; // use email address as the ledger identifier
        // Construct the personalDetails JSON object
        $personalDetails = [
            'name'              => $name,
            'email'             => $email,
            'national_id'       => $national_id,
            'dob'               => $dob,
            'permanent_address' => $permanent_address,
            // Store the hashed password for verification on login
            'password'          => password_hash($password, PASSWORD_DEFAULT),
            // All registered users are normal users by default
            'user_type'         => 'User'
        ];
        // Prepare the payload for chaincode invocation
        $payload = [
            'fcn'  => 'registerUser',
            'args' => [
                $userId,
                $national_id,
                json_encode($personalDetails)
            ]
        ];
        // Invoke the chaincode via the API
        $resp = callAPI('POST', API_BASE_URL . '/api/invoke', $payload);
        if ($resp && !empty($resp['ok'])) {
            // Registration succeeded; redirect to login with a flag
            header("location: login.php?registered=1");
            exit;
        } else {
            // Surface any error from the backend if available
            $registration_err = isset($resp['error']) ? $resp['error'] : 'Registration failed.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Land Administration System</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="form-wrapper">
            <?php if (isset($registration_err)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $registration_err; ?>
                </div>
            <?php endif; ?>
            <div class="form-header">
                <h2><i class="fas fa-user-plus"></i> User Registration</h2>
                <p>Please fill in your details to create an account.</p>
            </div>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group <?php echo (!empty($name_err)) ? 'has-error' : ''; ?>">
                    <label>Full Name</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-user"></i></span>
                        <input type="text" name="name" class="form-control" value="<?php echo $name; ?>">
                    </div>
                    <span class="help-block"><?php echo $name_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($national_id_err)) ? 'has-error' : ''; ?>">
                    <label>National ID</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-id-card"></i></span>
                        <input type="text" name="national_id" class="form-control" value="<?php echo $national_id; ?>">
                    </div>
                    <span class="help-block"><?php echo $national_id_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($email_err)) ? 'has-error' : ''; ?>">
                    <label>Email</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-envelope"></i></span>
                        <input type="email" name="email" class="form-control" value="<?php echo $email; ?>">
                    </div>
                    <span class="help-block"><?php echo $email_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($dob_err)) ? 'has-error' : ''; ?>">
                    <label>Date of Birth</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-calendar"></i></span>
                        <input type="date" name="dob" class="form-control" value="<?php echo $dob; ?>">
                    </div>
                    <span class="help-block"><?php echo $dob_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($permanent_address_err)) ? 'has-error' : ''; ?>">
                    <label>Permanent Address</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-home"></i></span>
                        <textarea name="permanent_address" class="form-control" rows="3"><?php echo $permanent_address; ?></textarea>
                    </div>
                    <span class="help-block"><?php echo $permanent_address_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
                    <label>Password</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-lock"></i></span>
                        <input type="password" name="password" class="form-control" value="<?php echo $password; ?>">
                    </div>
                    <span class="help-block"><?php echo $password_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>">
                    <label>Confirm Password</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-lock"></i></span>
                        <input type="password" name="confirm_password" class="form-control" value="<?php echo $confirm_password; ?>">
                    </div>
                    <span class="help-block"><?php echo $confirm_password_err; ?></span>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="Register">
                    <input type="reset" class="btn btn-default" value="Reset">
                </div>
                <div class="form-footer">
                    <p>Already have an account? <a href="login.php">Login here</a>.</p>
                </div>
            </form>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>
