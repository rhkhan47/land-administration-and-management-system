<?php
require_once "config.php";

// Only allow logged in non‑admin users
if (!isLoggedIn() || isAdmin()) {
    header("location: login.php");
    exit;
}

// Validate input parameters
if (!isset($_GET['action']) || !isset($_GET['land_id'])) {
    header("location: user_dashboard.php");
    exit;
}

$action  = $_GET['action'];
$land_id = $_GET['land_id'];
$user_id = $_SESSION["id"];

// Fetch the land from the ledger
$land = null;
$resp = callAPI('POST', API_BASE_URL . '/api/query', [
    'fcn'  => 'readLand',
    'args' => [$land_id]
]);
if ($resp && !empty($resp['ok'])) {
    $land = $resp['result'];
}

// Ensure the land exists and belongs to the user
if (!$land || $land['ownerId'] !== $user_id) {
    header("location: user_dashboard.php");
    exit;
}

// Only sales can be cancelled via the chaincode.  Validate status and action
if ($action !== 'sale' || ($land['status'] !== 'ForSale' && $land['status'] !== 'PendingSale')) {
    header("location: user_dashboard.php");
    exit;
}

// Derive human‑readable fields for display
$loc = $land['location'];
if (is_array($loc)) {
    $locationString = isset($loc['location']) ? $loc['location'] : '';
    $area           = isset($loc['area']) ? $loc['area'] : '';
    $deedHash       = isset($loc['deed_hash']) ? $loc['deed_hash'] : '';
} else {
    $locationString = $loc;
    $area = '';
    $deedHash = '';
}
$ipfs = isset($land['deedCid']) ? $land['deedCid'] : '';
$status = $land['status'];

$error = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $confirm = isset($_POST['confirm']) ? $_POST['confirm'] : 'no';
    if ($confirm === 'yes') {
        // Invoke the cancelSale chaincode function via its dedicated endpoint
        $respCancel = callAPI('POST', API_BASE_URL . '/api/cancelSale', [ 'landId' => $land_id ]);
        if ($respCancel && !empty($respCancel['ok'])) {
            header("location: user_dashboard.php?cancel_success=1");
            exit;
        } else {
            $error = isset($respCancel['error']) ? $respCancel['error'] : 'Error cancelling sale.';
        }
    } else {
        header("location: user_dashboard.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cancel Sale - Land Administration System</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1><i class="fas a-times-circle"></i> Cancel Sale</h1>
                <div class="user-info">
                    <div class="user-welcome">
                        <i class="fas a-user-circle"></i>
                        <span>Welcome, <?php echo $_SESSION["name"]; ?></span>
                    </div>
                    <div class="user-actions">
                        <a href="user_dashboard.php" class="btn btn-outline"><i class="fas a-arrow-left"></i> Back to Dashboard</a>
                        <a href="logout.php" class="btn btn-outline"><i class="fas a-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>
        </header>
        
        <div class="form-wrapper">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas a-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="land-details">
                <h3>Land Details</h3>
                <p><strong>Location:</strong> <?php echo htmlspecialchars($locationString); ?></p>
                <p><strong>Area:</strong> <?php echo htmlspecialchars($area); ?> sq ft</p>
                <p><strong>Current Status:</strong> <span class="status-<?php echo strtolower($status); ?>"><?php echo $status; ?></span></p>
                <?php if (!empty($ipfs)): ?>
                    <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo htmlspecialchars($ipfs); ?></span></p>
                <?php endif; ?>
                <?php if (!empty($deedHash)): ?>
                    <p><strong>Deed Hash:</strong> <span class="monospace"><?php echo htmlspecialchars($deedHash); ?></span></p>
                <?php endif; ?>
            </div>
            
            <div class="alert alert-warning">
                <i class="fas a-exclamation-triangle"></i>
                <h3>Are you sure you want to cancel this sale?</h3>
                <p>This will remove your land from the sale market and revert its status to Owned.</p>
            </div>
            
            <form method="post">
                <div class="form-group">
                    <div class="confirmation-options">
                        <label class="confirmation-option">
                            <input type="radio" name="confirm" value="yes" required>
                            <span>Yes, cancel the sale operation</span>
                        </label>
                        <label class="confirmation-option">
                            <input type="radio" name="confirm" value="no">
                            <span>No, keep the land listed for sale</span>
                        </label>
                    </div>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-warning"><i class="fas a-times-circle"></i> Confirm Cancellation</button>
                    <a href="user_dashboard.php" class="btn btn-default">Go Back</a>
                </div>
            </form>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>
