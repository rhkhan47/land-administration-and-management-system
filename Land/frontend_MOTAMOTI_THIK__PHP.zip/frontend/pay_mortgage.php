<?php
require_once "config.php";

// Only allow logged in non‑admin users
if (!isLoggedIn() || isAdmin()) {
    header("location: login.php");
    exit;
}

// Ensure a land_id is provided
if (!isset($_GET['land_id'])) {
    header("location: user_dashboard.php");
    exit;
}

$land_id = $_GET['land_id'];
$user_id = $_SESSION["id"];

// Fetch land details from the ledger
$land = null;
$resp = callAPI('POST', API_BASE_URL . '/api/query', [
    'fcn'  => 'readLand',
    'args' => [$land_id]
]);
if ($resp && !empty($resp['ok'])) {
    $land = $resp['result'];
}

// Ensure the land exists, belongs to the current user and has an active mortgage
if (!$land || $land['ownerId'] !== $user_id || !isset($land['mortgage']) || $land['mortgage']['status'] !== 'Active') {
    header("location: user_dashboard.php");
    exit;
}

// Derive human‑readable fields
$loc = $land['location'];
if (is_array($loc)) {
    $locationString = isset($loc['location']) ? $loc['location'] : '';
    $area           = isset($loc['area']) ? $loc['area'] : '';
    $deedHash       = isset($loc['deed_hash']) ? $loc['deed_hash'] : '';
} else {
    $locationString = $loc;
    $area = '';
    $deedHash = '';
}
$ipfs = isset($land['deedCid']) ? $land['deedCid'] : '';
$principal = isset($land['mortgage']['principal']) ? $land['mortgage']['principal'] : 0;
$duration  = isset($land['mortgage']['duration']) ? $land['mortgage']['duration'] : 0;

// Handle repayment on POST
$error = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $payload = [
        'fcn'  => 'repayMortgage',
        'args' => [$land_id]
    ];
    $invResp = callAPI('POST', API_BASE_URL . '/api/invoke', $payload);
    if ($invResp && !empty($invResp['ok'])) {
        // After successful repayment the land status becomes Owned
        header("location: user_dashboard.php?mortgage_repaid=1");
        exit;
    } else {
        $error = isset($invResp['error']) ? $invResp['error'] : "Error processing mortgage repayment.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Repay Mortgage - Land Administration System</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1><i class="fas a-credit-card"></i> Repay Mortgage</h1>
                <div class="user-info">
                    <a href="user_dashboard.php" class="btn btn-outline"><i class="fas a-arrow-left"></i> Back to Dashboard</a>
                    <a href="logout.php" class="btn btn-outline"><i class="fas a-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </header>
        
        <div class="form-wrapper">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas a-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="land-details">
                <h3>Mortgage Details</h3>
                <p><strong>Land Location:</strong> <?php echo htmlspecialchars($locationString); ?></p>
                <p><strong>Area:</strong> <?php echo htmlspecialchars($area); ?> sq ft</p>
                <p><strong>Mortgage Amount:</strong> ৳<?php echo number_format($principal, 2); ?></p>
                <p><strong>Duration:</strong> <?php echo $duration; ?> months</p>
                <?php if (!empty($ipfs)): ?>
                    <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo htmlspecialchars($ipfs); ?></span></p>
                <?php endif; ?>
                <?php if (!empty($deedHash)): ?>
                    <p><strong>Deed Hash:</strong> <span class="monospace"><?php echo htmlspecialchars($deedHash); ?></span></p>
                <?php endif; ?>
            </div>
            
            <form method="post">
                <div class="form-group">
                    <p>Click confirm to repay the mortgage amount of ৳<?php echo number_format($principal, 2); ?> and regain ownership of your land.</p>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary"><i class="fas a-credit-card"></i> Confirm Repayment</button>
                    <a href="user_dashboard.php" class="btn btn-default">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>
