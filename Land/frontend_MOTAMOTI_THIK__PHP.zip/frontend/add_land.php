<?php
require_once "config.php";

// Only allow logged in non-admin users to add land
if (!isLoggedIn() || isAdmin()) {
    header("location: login.php");
    exit;
}

// Initialise form values and error holders
$location = $area = $deed_hash = $ipfs_cid = $price = "";
$location_err = $area_err = $deed_hash_err = $ipfs_cid_err = $price_err = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate location
    if (empty(trim($_POST["location"]))) {
        $location_err = "Please enter land location.";
    } else {
        $location = trim($_POST["location"]);
    }
    
    // Validate area
    if (empty(trim($_POST["area"])) || !is_numeric($_POST["area"])) {
        $area_err = "Please enter a valid area.";
    } else {
        $area = trim($_POST["area"]);
    }
    
    // Validate deed hash
    if (empty(trim($_POST["deed_hash"]))) {
        $deed_hash_err = "Please enter deed hash.";
    } else {
        $deed_hash = trim($_POST["deed_hash"]);
    }
    
    // Validate IPFS CID
    if (empty(trim($_POST["ipfs_cid"]))) {
        $ipfs_cid_err = "Please enter IPFS CID.";
    } else {
        $ipfs_cid = trim($_POST["ipfs_cid"]);
    }
    
    // Validate price (we will include it as a hint in the location object)
    if (empty(trim($_POST["price"])) || !is_numeric($_POST["price"])) {
        $price_err = "Please enter a valid price.";
    } else {
        $price = trim($_POST["price"]);
    }
    
    // Check input errors before invoking chaincode
    if (empty($location_err) && empty($area_err) && empty($deed_hash_err) && empty($ipfs_cid_err) && empty($price_err)) {
        // Build a unique land identifier.  We use PHP's uniqid to ensure
        // uniqueness on the ledger.  In a production system you might
        // implement a more robust ID scheme.
        $land_id = uniqid("land");
        // Compose the location object.  The chaincode stores the
        // provided JSON directly and later decodes it on the ledger.
        $location_obj = [
            'location' => $location,
            'area'     => $area,
            // Persist the user-provided deed hash in the location object
            'deed_hash'=> $deed_hash,
            // Include an initial asking price hint; the actual sale price
            // will be set when the land is posted for sale after approval.
            'price'    => $price
        ];
        $payload = [
            'fcn'  => 'addLand',
            'args' => [
                $land_id,
                json_encode($location_obj),
                $ipfs_cid,
                $_SESSION["id"]
            ]
        ];
        $resp = callAPI('POST', API_BASE_URL . '/api/invoke', $payload);
        if ($resp && !empty($resp['ok'])) {
            header("location: user_dashboard.php?land_added=1");
            exit;
        } else {
            // Display a generic error message if something goes wrong
            echo "Something went wrong while adding your land. Please try again later.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Land - Land Administration System</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1><i class="fas fa-plus-circle"></i> Add New Land</h1>
                <div class="user-info">
                    <a href="user_dashboard.php" class="btn btn-outline"><i class="fas fa-arrow-left"></i> Back to Dashboard</a>
                    <a href="logout.php" class="btn btn-outline"><i class="fas a-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </header>
        
        <div class="form-wrapper">
            <p>Please fill in the details of your land. The Land Inspector will need to approve it before it appears in the system.</p>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group <?php echo (!empty($location_err)) ? 'has-error' : ''; ?>">
                    <label>Location</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-map-marker-alt"></i></span>
                        <input type="text" name="location" class="form-control" value="<?php echo $location; ?>">
                    </div>
                    <span class="help-block"><?php echo $location_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($area_err)) ? 'has-error' : ''; ?>">
                    <label>Area (sq ft)</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-ruler-combined"></i></span>
                        <input type="number" step="0.01" name="area" class="form-control" value="<?php echo $area; ?>">
                    </div>
                    <span class="help-block"><?php echo $area_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($price_err)) ? 'has-error' : ''; ?>">
                    <label>Price (৳)</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-tag"></i></span>
                        <input type="number" step="0.01" name="price" class="form-control" value="<?php echo $price; ?>">
                    </div>
                    <span class="help-block"><?php echo $price_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($deed_hash_err)) ? 'has-error' : ''; ?>">
                    <label>Deed Hash</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-hashtag"></i></span>
                        <input type="text" name="deed_hash" class="form-control" value="<?php echo $deed_hash; ?>">
                    </div>
                    <span class="help-block"><?php echo $deed_hash_err; ?></span>
                </div>
                <div class="form-group <?php echo (!empty($ipfs_cid_err)) ? 'has-error' : ''; ?>">
                    <label>IPFS CID</label>
                    <div class="input-group">
                        <span class="input-icon"><i class="fas fa-link"></i></span>
                        <input type="text" name="ipfs_cid" class="form-control" value="<?php echo $ipfs_cid; ?>">
                    </div>
                    <span class="help-block"><?php echo $ipfs_cid_err; ?></span>
                </div>
                <div class="form-group">
                    <input type="submit" class="btn btn-primary" value="Submit">
                    <a href="user_dashboard.php" class="btn btn-default">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>
