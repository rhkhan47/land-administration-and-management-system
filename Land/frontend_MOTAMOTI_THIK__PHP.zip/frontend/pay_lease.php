<?php
require_once "config.php";

// Only allow logged in non‑admin users
if (!isLoggedIn() || isAdmin()) {
    header("location: login.php");
    exit;
}

// Ensure a land_id is provided
if (!isset($_GET['land_id'])) {
    header("location: user_dashboard.php");
    exit;
}

$land_id = $_GET['land_id'];
$user_id = $_SESSION["id"];

// Fetch land details from the ledger
$land = null;
$resp = callAPI('POST', API_BASE_URL . '/api/query', [
    'fcn'  => 'readLand',
    'args' => [$land_id]
]);
if ($resp && !empty($resp['ok'])) {
    $land = $resp['result'];
}

// Ensure the land exists, has an active lease and the current user is the tenant
if (!$land || !isset($land['lease']) || $land['lease']['status'] !== 'Active' || $land['lease']['tenantId'] !== $user_id) {
    header("location: user_dashboard.php");
    exit;
}

// Derive human‑readable fields
$loc = $land['location'];
if (is_array($loc)) {
    $locationString = isset($loc['location']) ? $loc['location'] : '';
    $area           = isset($loc['area']) ? $loc['area'] : '';
    $deedHash       = isset($loc['deed_hash']) ? $loc['deed_hash'] : '';
} else {
    $locationString = $loc;
    $area = '';
    $deedHash = '';
}
$ipfs = isset($land['deedCid']) ? $land['deedCid'] : '';
$rent     = isset($land['lease']['rent']) ? $land['lease']['rent'] : 0;
$duration = isset($land['lease']['duration']) ? $land['lease']['duration'] : 0;
$payments = isset($land['lease']['payments']) ? $land['lease']['payments'] : [];
$paymentsMade = is_array($payments) ? count($payments) : 0;

// Handle rent payment on POST
$error = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Only allow payment if there are remaining payments
    if ($paymentsMade >= $duration) {
        $error = "All lease payments have already been made.";
    } else {
        $payload = [
            'fcn'  => 'payRent',
            'args' => [$land_id, $user_id, strval($rent)]
        ];
        $invResp = callAPI('POST', API_BASE_URL . '/api/invoke', $payload);
        if ($invResp && !empty($invResp['ok'])) {
            header("location: user_dashboard.php?lease_paid=1");
            exit;
        } else {
            $error = isset($invResp['error']) ? $invResp['error'] : "Error processing lease payment.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pay Rent - Land Administration System</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="header-content">
                <h1><i class="fas a-money-bill-wave"></i> Pay Rent</h1>
                <div class="user-info">
                    <a href="user_dashboard.php" class="btn btn-outline"><i class="fas a-arrow-left"></i> Back to Dashboard</a>
                    <a href="logout.php" class="btn btn-outline"><i class="fas a-sign-out-alt"></i> Logout</a>
                </div>
            </div>
        </header>
        
        <div class="form-wrapper">
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas a-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <div class="land-details">
                <h3>Lease Details</h3>
                <p><strong>Land Location:</strong> <?php echo htmlspecialchars($locationString); ?></p>
                <p><strong>Area:</strong> <?php echo htmlspecialchars($area); ?> sq ft</p>
                <p><strong>Monthly Rent:</strong> ৳<?php echo number_format($rent, 2); ?></p>
                <p><strong>Duration:</strong> <?php echo $duration; ?> months</p>
                <p><strong>Payments Made:</strong> <?php echo $paymentsMade; ?> / <?php echo $duration; ?></p>
                <?php if (!empty($ipfs)): ?>
                    <p><strong>IPFS CID:</strong> <span class="monospace"><?php echo htmlspecialchars($ipfs); ?></span></p>
                <?php endif; ?>
                <?php if (!empty($deedHash)): ?>
                    <p><strong>Deed Hash:</strong> <span class="monospace"><?php echo htmlspecialchars($deedHash); ?></span></p>
                <?php endif; ?>
            </div>
            
            <?php if ($paymentsMade < $duration): ?>
                <form method="post">
                    <div class="form-group">
                        <p>You are about to pay the monthly rent of ৳<?php echo number_format($rent, 2); ?> for this lease.</p>
                    </div>
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fas a-money-bill-wave"></i> Confirm Payment</button>
                        <a href="user_dashboard.php" class="btn btn-default">Cancel</a>
                    </div>
                </form>
            <?php else: ?>
                <div class="alert alert-info">
                    <i class="fas a-info-circle"></i> All lease payments have been completed. Thank you!
                </div>
                <a href="user_dashboard.php" class="btn btn-default">Back to Dashboard</a>
            <?php endif; ?>
        </div>
    </div>
    <script src="js/script.js"></script>
</body>
</html>
